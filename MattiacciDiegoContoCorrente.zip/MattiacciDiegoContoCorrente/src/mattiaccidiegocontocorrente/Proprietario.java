/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mattiaccidiegocontocorrente;

/**
 *
 * @author matti_3x0xxn1
 */
public class Proprietario {
    
}
