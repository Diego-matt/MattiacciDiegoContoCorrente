/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mattiaccidiegocontocorrente;

/**
 *
 * @author matti_3x0xxn1
 */
public class MattiacciDiegoContoCorrente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        ContoCorrente cc = new ContoCorrente( "diego" , "mattiacci", 1000);
        
        //metodo prelievo
        cc.prelievo(100);
        System.out.println(cc.toString());
        
        System.out.println();
       
        //metodo prelievo inferiore
        cc.prelievo(1000);
        System.out.println(cc.toString());
        
        System.out.println();
        
        //metdo versamento
        cc.versamento(10000);
        System.out.println(cc.toString());
        
       
        
        

        
        
        
    }
    
}
