/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mattiaccidiegocontocorrente;

/**
 *
 * @author matti_3x0xxn1
 */
public class ContoCorrente {
 
 private String nome;
 private String cognome;
 private float saldo;
    
  /**
   * metodo costruttore
   * @param nome nome del proprietario
   * @param cognome cognome del proprietario
   * @param saldo saldo del proprietario
   */
 
 public ContoCorrente(String nome, String cognome, float saldo){
     
     this.nome = nome;
     this.cognome = cognome;
     this.saldo = saldo;
     
 }
 
 /**
  * Restituisce il nome del titolare del conto.
  * @return il nome del proprietario
  */
 public String getNome()
 {
     
  return this.nome;
     
 }
 /**
  * Restituisce il nome del titolare del conto.
  * @return il cognome del proprietario
  */
 public String getCognome()
 {
     
     return this.cognome;
 }
 /**
  * Restituisce il saldo del titolare del conto
  * @return Il nome del proprietario
  */
 public Float getSaldo()
 {
  
     return this.saldo;
 
 }
 
 /**
  * Modifica il nome del titolare del conto
  * @param nome Il nuovo nome da impostare
  * @return Il nuovo valore del nome
  */
 public String setNome(String nome)
 {
     
  this.nome = nome;
  return this.nome;
     
 }
 
 /**
  * Modifica il cognome del titolare del conto
  * @param cognome Il nuovo nome da impostare
  * @return il nuovo valore del cognome
  */
 public String setCognome(String cognome)
 {
     
   this.cognome = cognome;
   return this.nome;
     
     
 }
 /**
  * applica un prelievo al saldo
  * @param denaro quanto voglio prelevare
  */
 public void prelievo(float denaro){
     
     if(this.saldo < denaro ) 
   {
       
       System.out.println("non puoi effettuare il prelievo");
               
    }
  
   else
   {
       
       this.saldo = this.saldo - denaro;
      
   }
        
     
     
 }
 /**
  * applica un versamente al saldo
  * @param denaro quanto voglio versare 
  */
 public void versamento(float denaro){
    
   this.saldo = this.saldo + denaro;
    
    
}
 
 
 /**
  * metodo tostring
  * @return lo stato del conto cortrente
  */
 public String toString()
 {
     
     return "Conto corrente di" + " " + this.nome + " " + this.cognome + " " + "ha un saldo di" + " " + this.saldo + "€";
     
     
     
 }

 
}
 


